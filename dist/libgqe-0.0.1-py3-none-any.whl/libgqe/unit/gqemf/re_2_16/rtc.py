"""RTC commands"""
from libgqe.unit.gqemf.re_2_00.rtc import RTC as RTC_2_00


class RTC(RTC_2_00):
    """RTC class"""
