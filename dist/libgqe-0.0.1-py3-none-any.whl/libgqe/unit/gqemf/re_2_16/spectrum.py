"""Spectrum analyzer commands"""
from libgqe.unit.gqemf.re_2_00.spectrum import Spectrum as Spectrum_2_00


class Spectrum(Spectrum_2_00):
    """Spectrum analyzer class"""
