"""SPI commands"""
from libgqe.unit.gqemf.re_2_00.spi import SPI as SPI_2_00


class SPI(SPI_2_00):
    """SPI class"""
