"""SPI commands"""
from libgqe.unit.gqemf.re_1_00.spi import SPI as SPI_1_00


class SPI(SPI_1_00):
    """SPI class"""
